import unittest
from backend.server_directory import extract_servers,resolve

class DirectoryTests(unittest.TestCase):
    def setUp(self):
        self.records=extract_servers({'data':{'servers':[{'id':1,'name':'Faraway','ip':'faraway.arizona-rp.com','port':7777},{'name':'Phoenix','ip':'phoenix.arizona-rp.com','port':7777}]}})
    def test_host(self):
        result,error=resolve('FARAWAY.ARIZONA-RP.COM.',7777,self.records)
        self.assertEqual(result['name'],'Faraway')
        self.assertIsNone(error)
    def test_numeric(self):
        result,error=resolve('203.0.113.7',7777,self.records,lambda h: {'203.0.113.7'} if h.startswith('faraway') else {'203.0.113.8'})
        self.assertEqual(result['name'],'Faraway')
    def test_ambiguous(self):
        result,error=resolve('203.0.113.7',7777,self.records,lambda h: {'203.0.113.7'})
        self.assertIsNone(result)
        self.assertEqual(error,'ambiguous_match')
    def test_unknown(self):
        result,error=resolve('unknown.arizona-rp.com',7777,self.records)
        self.assertIsNone(result)
if __name__=='__main__':unittest.main()
