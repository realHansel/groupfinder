import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient

class APITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        os.environ['AGF_DATABASE']=str(Path(self.tmp.name)/'test.sqlite3')
        import importlib, backend.main
        self.m=importlib.reload(backend.main)
        self.m.init()
        self.api=TestClient(self.m.app)
        self.t=self.api.post('/api/v1/session').json()['token']
        self.h={'Authorization':'Bearer '+self.t}
        self.directory_patch=patch.object(self.m,'directory',return_value=[{'key':'faraway.arizona-rp.com:7777','host':'faraway.arizona-rp.com','port':7777,'name':'Faraway'}])
        self.directory_patch.start()
        self.data={'nickname':'Nacho_Goodman','player_id':123,'game_server':'faraway.arizona-rp.com:7777','job':'taxi','kind':'looking','members':1}
    def tearDown(self):
        self.directory_patch.stop()
        self.tmp.cleanup()
    def test_flow(self):
        self.assertEqual(self.api.post('/api/v1/listings',headers=self.h,json=self.data).status_code,200)
        self.assertEqual(len(self.api.get('/api/v1/listings',params={'game_server':'faraway.arizona-rp.com:7777'}).json()['listings']),1)
        self.assertEqual(len(self.api.get('/api/v1/listings',params={'game_server':'other.game:7777'}).json()['listings']),0)
        self.assertEqual(self.api.post('/api/v1/heartbeat',headers=self.h).json()['active'],True)
        self.assertEqual(self.api.delete('/api/v1/listings/me',headers=self.h).status_code,200)
        self.assertEqual(self.api.get('/api/v1/listings',params={'game_server':'faraway.arizona-rp.com:7777'}).json()['listings'],[])
    def test_validation(self):
        bad=dict(self.data,nickname='!bad')
        self.assertEqual(self.api.post('/api/v1/listings',headers=self.h,json=bad).status_code,422)
        self.assertEqual(self.api.post('/api/v1/listings',json=self.data).status_code,401)
        bad=dict(self.data,members=5,kind='recruiting')
        self.assertEqual(self.api.post('/api/v1/listings',headers=self.h,json=bad).status_code,422)
    def test_resolve(self):
        records=[{'key':'faraway.arizona-rp.com:7777','host':'faraway.arizona-rp.com','port':7777,'name':'Faraway'}]
        with patch.object(self.m,'resolve',return_value=(records[0],None)):
            response=self.api.get('/api/v1/servers/resolve',params={'address':'faraway.arizona-rp.com','port':7777})
            self.assertEqual(response.status_code,200)
            self.assertEqual(response.json()['server_id'],records[0]['key'])
        with patch.object(self.m,'resolve',return_value=(None,'unknown_server')):
            self.assertEqual(self.api.get('/api/v1/servers/resolve',params={'address':'bad.example','port':7777}).status_code,404)
if __name__=='__main__':unittest.main()
